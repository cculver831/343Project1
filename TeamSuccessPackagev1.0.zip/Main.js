/**
 * Author: Chloe
 * Contact: C.culver831@gmail.com
 * Completed: 3/4/2020
 * This script acts as an interface for the user to use the CopyFiles Script
 */


 //Creat constant Read line to receive user input
const readline = require("readline");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


//Asks user for input i.e. File loaction and File destination
rl.question("Welcome to Team Success VCS!! Please enter the path of the Source Folder: ", function(sourceFolder) {
    rl.question("Please enter the Target Folder Destination: ", function(targetFolder) {
        console.log(`${sourceFolder}, contents are being repo'd to Target Destination: ${targetFolder}`);
        //'Calls' the copy file function which inturn call the ReadFile and Artifact scripts to run
        let copyFiles = require('./CopyFiles')(sourceFolder,targetFolder);
        copyFiles.Result;
        //Print statement to show completion
        console.log("Congratulations! You're repo was a success. Check your Target Folder to see what's happened");  
        console.log("Press CRTL + C to exit the program");
    
    });
});
